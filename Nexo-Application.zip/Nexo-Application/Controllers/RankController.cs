﻿using Microsoft.AspNetCore.Mvc;
using NexoApplication.Data;
using NexoApplication.Models.Entities;
using NexoApplication.Models.Services;
using System.Collections;
using System.Collections.Generic;

namespace Nexo_Application.Controllers
{
    public class RankController : Controller
    {
        private readonly NexoDbContext _dbContext;
        private readonly ClienteService _clienteService;
        
        public RankController(NexoDbContext context)
        {
            _dbContext = context;
            _clienteService = new ClienteService(context);
        }

        public IActionResult Index()
        {
            ViewBag.SilverClients = _clienteService.GetSilverClients();
            ViewBag.GoldClients = _clienteService.GetGoldClients();
            ViewBag.PlatinumClients =  _clienteService.GetPlatinumClients();
            ViewBag.DiamondClients = _clienteService.GetDiamondClients();

            return View();
        }
    }
}
