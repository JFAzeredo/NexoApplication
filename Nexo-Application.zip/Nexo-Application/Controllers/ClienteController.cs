﻿using Microsoft.AspNetCore.Mvc;
using NexoApplication.Data;
using NexoApplication.Models.Entities;
using NexoApplication.Models.Services;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace NexoApplication.Controllers
{
    public class ClienteController : Controller
    {
        private readonly NexoDbContext _dbContext;
        private readonly ClienteService _clienteService;

        public ClienteController(NexoDbContext context, ClienteService clienteService)
        {
            _dbContext = context;
            _clienteService = clienteService;
        }

        public IActionResult Index()
        {
            IEnumerable<Cliente> clientes = _dbContext.Clientes;
            return View(clientes);
        }

        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Cliente cliente)
        {
            if (ModelState.IsValid)
            {
                DateTime dataCriacao = DateTime.Now;
                cliente.DataCadastro = dataCriacao;
                await _dbContext.Clientes.AddAsync(cliente);
                await _dbContext.SaveChangesAsync();
                return await Task.Run(() => RedirectToAction("Index"));
            }
            return await Task.Run(() => View(cliente));
        }


        public async Task<IActionResult> Edit(int id)
        {
            var cliente = await _dbContext.Clientes.FindAsync(id);

            if (cliente == null) return NotFound();

            return await Task.Run(() => View(cliente));
        }


        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(Cliente cliente)
        {
            if (ModelState.IsValid)
            {
                _dbContext.Clientes.Update(cliente);
                await _dbContext.SaveChangesAsync();
                return await Task.Run(() => RedirectToAction("Index"));
            }
            return await Task.Run(() => View(cliente));
        }

        public async Task<IActionResult> Delete(int id)
        {
            var cliente = await _dbContext.Clientes.FindAsync(id);

            if (cliente == null) return NotFound();

            return await Task.Run(() => View(cliente));
        }


        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteCliente(int id)
        {
            var cliente = _dbContext.Clientes.Find(id);
            if (cliente != null)
            {
                _dbContext.Clientes.Remove(cliente);
                await _dbContext.SaveChangesAsync();
                return await Task.Run(() => RedirectToAction("Index"));
            } else
            {
                return NotFound();
            }
        }

        [HttpGet]
        public IActionResult Busca(string master)
        {
            List<Cliente> clientes = _clienteService.FindByMaster(master);
            return View(clientes);
        }
    }
}
