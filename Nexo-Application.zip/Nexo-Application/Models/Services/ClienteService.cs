﻿using Microsoft.EntityFrameworkCore;
using NexoApplication.Data;
using NexoApplication.Models.Entities;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace NexoApplication.Models.Services
{
    public class ClienteService
    {
        private readonly NexoDbContext _dbContext;

        public ClienteService(NexoDbContext context)
        {
            _dbContext = context;
        }

        public List<Cliente> GetAllClients()
        {
            return _dbContext.Clientes.ToList();
        }

        public List<Cliente> GetSilverClients()
        {
            DateTime timeToday = DateTime.Now;
            timeToday.Subtract(timeToday.AddYears(-5));
            List<Cliente> clientes = _dbContext.Clientes.Where(cliente => cliente.DataCadastro > timeToday).ToList();
            return clientes;
        }

        public List<Cliente> GetGoldClients()
        {
            List<Cliente> Clientes = _dbContext.Clientes.ToList();
            List<Cliente> goldClientes = new List<Cliente>();

            foreach(Cliente cliente in Clientes)
            {
                List<Produto> produtos = _dbContext.Produtos.Where(produto => produto.ClienteId == cliente.ClienteId).ToList();
                if (produtos.Count >= 2000 && produtos.Count <= 5000)
                {
                    goldClientes.Add(cliente);
                }
            }
            return goldClientes;
        }

        public List<Cliente> GetPlatinumClients()
        {
            List<Cliente> Clientes = _dbContext.Clientes.ToList();
            List<Cliente> platinumClientes = new List<Cliente>();

            foreach (Cliente cliente in Clientes)
            {
                List<Produto> produtos = _dbContext.Produtos.Where(produto => produto.ClienteId == cliente.ClienteId).ToList();
                if (produtos.Count > 5000 && produtos.Count <= 10000)
                {
                    platinumClientes.Add(cliente);
                }
            }
            return platinumClientes;
        }

        public List<Cliente> GetDiamondClients()
        {
            List<Cliente> Clientes = _dbContext.Clientes.ToList();
            List<Cliente> diamondClientes = new List<Cliente>();

            foreach (Cliente cliente in Clientes)
            {
                List<Produto> produtos = _dbContext.Produtos.Where(produto => produto.ClienteId == cliente.ClienteId).ToList();
                if (produtos.Count > 10000)
                {
                    diamondClientes.Add(cliente);
                }
            }
            return diamondClientes;
        }

        public List<Cliente> FindByMaster(string master)
        {
            if (master == null) master = "prata";
            
            master = master.ToLower();
            List<Cliente> clientes = new List<Cliente>();

            if (master == "prata")
            {
                clientes = GetSilverClients();
            }
            else if (master == "ouro")
            {
                clientes = GetGoldClients();
            }
            else if (master == "platina")
            {
                clientes = GetPlatinumClients();
            }
            else
            {
                clientes = GetDiamondClients();
            }

            return clientes;
        }
    }
}
