﻿using NexoApplication.Data;
using NexoApplication.Models.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace NexoApplication.Models.Services
{
    public class ProdutoService
    {
        private readonly NexoDbContext _dbContext;
    
        public ProdutoService(NexoDbContext context)
        {
            _dbContext = context;
        }


        public async Task<string> GetClientNameFromProduct(int id)
        {
            var cliente = await _dbContext.Clientes.FindAsync(id);
            return cliente.Nome;
        }

        public IEnumerable<Produto> getProdutoByName(string productName)
        {
            List<Produto> produtos = _dbContext.Produtos.ToList();
            productName.ToLower();
            var p1 = from p in produtos
                     where p.Nome.ToLower() == productName
                     select p as Produto;
            return p1;
        }
    }
}
